package zingoGame;



import javax.swing.*;
 import javax.swing.event.*;

import java.util.Random;
import java.applet.Applet;
import java.applet.AudioClip;
import java.awt.BorderLayout;
 import java.awt.Color;
 import java.awt.SystemColor;
 import java.awt.Component;
 import java.awt.FlowLayout;
 import java.awt.GridLayout;
 import java.awt.event.*;
import java.net.URL;
 public class level2 extends JFrame{
  
 Random rad = new Random(); 
 private JLabel L1,L2,L3,L4,Ltimer,computerScore,userScore,none,none1;
 private final JButton[] btns = new JButton[18];
 private int z=0;
 private JButton cbtn1,bagain,bcancel,bBACK;
 private Icon randompic1;
 private Icon randompic2;
 int rx = rad.nextInt(9);
int rxx = rad.nextInt(9)+9;
 private JPanel pRight,pCenter,pLeft,pc1,pc2,pc3,pbtns;
  
 private static String[] allpic = {"P1.jpg","P2.jpg","P3.jpg","P4.jpg","P5.jpg","P6.jpg","P7.jpg","P8.jpg","P9.jpg","C1.jpg",
                           "C2.jpg","C3.jpg","C4.jpg","C5.jpg","C6.jpg","C7.jpg","C8.jpg","C9.jpg","18.jpg"
                           ,"19.png","20.png"};
  
 private final Icon[] allpics = 
 {new ImageIcon(getClass().getResource(allpic[0]))
 ,new ImageIcon(getClass().getResource(allpic[1])),new ImageIcon(getClass().getResource(allpic[2]))
 ,new ImageIcon(getClass().getResource(allpic[3])),new ImageIcon(getClass().getResource(allpic[4]))
 ,new ImageIcon(getClass().getResource(allpic[5])),new ImageIcon(getClass().getResource(allpic[6]))
 ,new ImageIcon(getClass().getResource(allpic[7])),new ImageIcon(getClass().getResource(allpic[8]))
 ,new ImageIcon(getClass().getResource(allpic[9])),new ImageIcon(getClass().getResource(allpic[10]))
 ,new ImageIcon(getClass().getResource(allpic[11])),new ImageIcon(getClass().getResource(allpic[12]))
 ,new ImageIcon(getClass().getResource(allpic[13])),new ImageIcon(getClass().getResource(allpic[14]))
 ,new ImageIcon(getClass().getResource(allpic[15])),new ImageIcon(getClass().getResource(allpic[16]))
 ,new ImageIcon(getClass().getResource(allpic[17])),
 
 };
 private JLabel lblNewLabel;
 private JLabel lblNewLabel_1;
 private Timer timer;
 public URL [] S=new URL[2];
 
 public level2() {
  
super(" Challenging");

//_Timer____________________________________________________________________________//
	y tc = new y();
	timer = new Timer(7500,tc);
	timer.start();

 //_Main Panel____________________________________________________________________________//
  againHandler a =new againHandler();
  getContentPane().setLayout (new BorderLayout());
  
  pRight=new JPanel();
  pRight.setLayout(new GridLayout(3,3,5,5));
    
  pLeft=new JPanel();
  pLeft.setLayout(new GridLayout(3,3,5,5));
 
  pCenter=new JPanel();
  pCenter.setLayout(new GridLayout(3,1,0,0)); 
   
  Ltimer = new JLabel("<html>Match the upper picture with your board <br> &nbsp;&nbsp;&nbsp;&nbsp;You have only 7 seconds to chose!</html>");
  Ltimer.setHorizontalAlignment(JLabel.CENTER);
  pCenter.add( Ltimer);
  
  getContentPane().add(pRight,BorderLayout.EAST);
  getContentPane().add(pLeft,BorderLayout.WEST);
  getContentPane().add(pCenter,BorderLayout.CENTER);
  
  
  
  S[0]= zingoGameA.class.getResource("loser.wav");
  S[1]= zingoGameA.class.getResource("win.wav");
 
  
  //__Building Buttons_____________________________________________________________________________________________________//
  
  // RIGHTPanel
  for (int i =0;i<9;i++){
  btns[i]=new JButton ("",allpics[i]);
  btns[i].setBackground(Color.lightGray);
  btns[i].setOpaque(true);
  pRight.add(btns[i]); 
  y handler1 = new y();
  btns[i].addActionListener(handler1);
  }
  // LeftPanel
  for (int i =9;i<18;i++){
  btns[i]=new JButton ("",allpics[i]);
  btns[i].setBackground(Color.lightGray);
  btns[i].setOpaque(true);
  pLeft.add(btns[i]);
  }
  	
  //_Makig random pic ____________________________________________________________________________//
	  L3 = new JLabel( );
	  L4 = new JLabel( );
   	   	    
	  this. rx = rad.nextInt(9);
	  this.rxx = rad.nextInt(9)+9;
	    
	  L3.setIcon(allpics[rx]);
	  L4.setIcon(allpics[rxx]);
	      
	  L3.setHorizontalAlignment(JLabel.CENTER);
	  L4.setHorizontalAlignment(JLabel.CENTER);  
     
	  pCenter.add(L3);
	  pCenter.add(L4);
	  
 //_Paly again/ cancel /BACK____________________________________________________________________________//
	  pbtns =new JPanel();
	  getContentPane().add(pbtns,BorderLayout.SOUTH);
	  
	  bagain = new JButton("PLAY AGAIN");
	  bBACK = new JButton("BACK");
	  bcancel = new JButton(" EXIT ");
	  
	  lblNewLabel = new JLabel("COMPUTER                                                            ");
	  lblNewLabel.setHorizontalAlignment(SwingConstants.LEFT);
	  pbtns.add(lblNewLabel);
	  pbtns.add(bagain);
	  pbtns.add(bBACK);
	  pbtns.add(bcancel);
	  
	  lblNewLabel_1 = new JLabel("                                                            PLAYER");
	  lblNewLabel_1.setHorizontalAlignment(SwingConstants.RIGHT);
	  pbtns.add(lblNewLabel_1);
	   
	  L3.setHorizontalAlignment(JLabel.CENTER);
	  L4.setHorizontalAlignment(JLabel.CENTER);
	  
	  
	 // handle action from play again button------------------------------------------------------------------
	  bagain.addActionListener(new ActionListener(){
	  @Override
	  public void actionPerformed(ActionEvent event){
	       for (int i =0;i<18;i++){
	       btns[i].setBackground(Color.lightGray);
	    btns[i].setOpaque(true);
	    z=0;
	    
	    rx = rad.nextInt(9);
	    rxx = rad.nextInt(9)+9;
	    L3.setIcon(allpics[rx]);
	    L4.setIcon(allpics[rxx]);
	    timer.start();
		
	  }
	  } 
	  });
  
     // handle action from cancel button---------------------------------------------------------------
	  bcancel.addActionListener(new ActionListener(){
	  @Override
	  public void actionPerformed(ActionEvent event){
	  System.exit(0);
	  }
	  });
	  
	// handle action from back button-------------------------------------------------------------------- 
	  bBACK.addActionListener(new ActionListener(){
		  @Override
		  public void actionPerformed(ActionEvent event){
		       
				 dispose();
					Start ob = new Start();
					ob.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					ob.setSize(1025,650);
					ob.setVisible(true);
					ob.setLocationRelativeTo(null);
					ob.setResizable(false);

			
		
		  } 
		  });
	    
}// end constructor
  private class againHandler implements ActionListener {

        public void actionPerformed(ActionEvent event) {
        for (int i =0;i<18;i++){
          btns[i].setBackground(Color.lightGray);
	      btns[i].setOpaque(true);
	      z=0;
	      rx = rad.nextInt(9);
	      rxx = rad.nextInt(9)+9;
	      L3.setIcon(allpics[rx]);
	      L4.setIcon(allpics[rxx]);
	      timer.start();
		  
    }    
   }
  }
  
 public class y implements ActionListener  {
	
 public void actionPerformed(ActionEvent event){
	 if(z==0){
		  for(int i=0;i<9;i++){
			   {if (event.getSource() == (btns[rx])){
				     btns[rx].setBackground(Color.green);
				     timer.stop();
			   }
		
			    btns[rxx].setBackground(Color.yellow);
			    timer.stop();
			   }
			   
			   if (event.getSource() == (btns[rx]) && z!=1){
				   btns[rx].setBackground(Color.GREEN);
				   btns[rxx].setBackground(Color.yellow);
				   timer.stop();
				   }
		   break;
		  }
		  }
		  
		  if(z==0){
				   rx = rad.nextInt(9);
				   rxx = rad.nextInt(9)+9;
				   L3.setIcon(allpics[rx]);
				   L4.setIcon(allpics[rxx]);
				   timer.start();
				   
					
					 player();
					 
					 computer();
				 
		  }
		 }
}
  public void player(){
	  if(z==0){
	  if ((btns[0].getBackground()==Color.green &&btns[1].getBackground()==Color.green &&btns[2].getBackground()==Color.green )
		      || (btns[3].getBackground()==Color.green &&btns[4].getBackground()==Color.green &&btns[5].getBackground()==Color.green )
		      || (btns[6].getBackground()==Color.green &&btns[7].getBackground()==Color.green &&btns[8].getBackground()==Color.green )
		      || (btns[0].getBackground()==Color.green &&btns[3].getBackground()==Color.green &&btns[6].getBackground()==Color.green )
		      || (btns[1].getBackground()==Color.green &&btns[4].getBackground()==Color.green &&btns[7].getBackground()==Color.green )
		      || (btns[2].getBackground()==Color.green &&btns[5].getBackground()==Color.green &&btns[8].getBackground()==Color.green )
		      || (btns[0].getBackground()==Color.green &&btns[4].getBackground()==Color.green &&btns[8].getBackground()==Color.green )
		      || (btns[2].getBackground()==Color.green &&btns[4].getBackground()==Color.green &&btns[6].getBackground()==Color.green )
		    ){
		  
		  AudioClip clip=Applet .newAudioClip(S[1]);
			  clip.play();timer.stop();ImageIcon icon=new ImageIcon(getClass().getResource("morehappyV.png"));
		      JOptionPane.showMessageDialog(null, " GOOD JOB! ","Yaah!",JOptionPane.INFORMATION_MESSAGE,icon);
		      z=1; 
		      }
	  }
  }
  
  public void computer(){
	  if(z==0){
	  if ((btns[9].getBackground()==Color.yellow &&btns[10].getBackground()==Color.yellow &&btns[11].getBackground()==Color.yellow )
		       || (btns[12].getBackground()==Color.yellow &&btns[13].getBackground()==Color.yellow &&btns[14].getBackground()==Color.yellow )
		       || (btns[15].getBackground()==Color.yellow &&btns[16].getBackground()==Color.yellow &&btns[17].getBackground()==Color.yellow )
		       || (btns[9].getBackground()==Color.yellow &&btns[12].getBackground()==Color.yellow &&btns[15].getBackground()==Color.yellow )
		       || (btns[10].getBackground()==Color.yellow &&btns[13].getBackground()==Color.yellow &&btns[16].getBackground()==Color.yellow )
		       || (btns[11].getBackground()==Color.yellow &&btns[14].getBackground()==Color.yellow &&btns[17].getBackground()==Color.yellow )
		       || (btns[9].getBackground()==Color.yellow &&btns[13].getBackground()==Color.yellow &&btns[17].getBackground()==Color.yellow )
		       || (btns[11].getBackground()==Color.yellow &&btns[13].getBackground()==Color.yellow &&btns[15].getBackground()==Color.yellow )
		      ){
		  
		  
		  AudioClip clip=Applet .newAudioClip(S[0]);
	 		 clip.play();timer.stop();
	 		 ImageIcon icon=new ImageIcon(getClass().getResource("sadV.png"));
		     JOptionPane.showMessageDialog(null, " Instead of giving up, try again  ","Ohh!",JOptionPane.INFORMATION_MESSAGE,icon);
		     z=1;
		     }
  }
	  }
  
  
  	  
 public static void main(String[] args) {
 level2 ob = new level2();
 ob.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
 ob.setSize(1100,500);
 ob.setVisible(true);
 //ob.setResizable(false);
 ob.setLocationRelativeTo(null);

 }
}