package zingoGame;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class info extends JFrame {
	private Icon pic;
	private JPanel p;
	private JLabel L1,L2;
	
	public info(){
		
		super("Instructions!");
		
	
		
						
		L2 = new JLabel("Message Here");
		L2 = new JLabel("<html><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Instructions:</b> <br> 1.Choose a level "
				+ "(Normal/Challenging). <br> 2.Click on the image in the right"
				+ " board <br>if it matches the upper image.<br>	3.	Try to match 3 images in a row,column or diagonal to win! </html>  ");

		L2.setForeground(new Color(250,250,250));
		L2.setHorizontalAlignment(JLabel.CENTER);
		
		
		getContentPane().add(L2,SwingConstants.CENTER);
		getContentPane().setBackground(new Color(56,127,65));
		
	}

	public static void main(String[] args) {
		info ob= new info();
		ob.setBackground(Color.WHITE);
		ob.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ob.setSize(460,180);
		ob.setResizable(false);
		ob.setVisible(true);
		ob.setLocationRelativeTo(null);
	   
	}

}
