package zingoGame;


import java.applet.Applet;
import java.applet.AudioClip;
import java.awt.*;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionListener;
import java.net.URL;
import java.awt.event.ActionEvent;




import javax.swing.*;
import javax.swing.event.*;


import java.util.Random;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.SystemColor;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.*;
public class Start extends JFrame {

	public URL sound;
	private JPanel contentPane;
	JFrame fr;
	private final JLabel lblNewLabe = new JLabel("");
	
	

	/**
	 * Create the frame
	 */
	
	public Start() {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(550,320,1000,630);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(3, 3, 4, 4));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		sound= zingoGameA.class.getResource("start.wav");
		
		
		//Game window level one-------------------------------------------------------------------
		JButton btnStart1 = new JButton("Normal Level");
		btnStart1.setBackground(new Color(245, 222, 179));
		btnStart1.setForeground(new Color(47, 79, 79));
		//btnStart1.setBackground(new Color(0, 0, 0));
		btnStart1.setBounds(450, 350, 151, 30);
		contentPane.add(btnStart1);
		btnStart1.setOpaque(true);
		
		btnStart1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			 AudioClip clip=Applet .newAudioClip(sound);
								 clip.play();
								 dispose();
				
				zingoGameA ob = new zingoGameA();
				ob.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				ob.setSize(1100,500);
				ob.setVisible(true);
				ob.setLocationRelativeTo(null);
			}
		});
		
		//Game window level two------------------------------------------------------------------------
		JButton btnStart2 = new JButton("Challenging Level");
		btnStart2.setBackground(new Color(245, 222, 179));
		btnStart2.setForeground(new Color(47, 79, 79));
		//btnStart2.setBackground(new Color(255, 255, 255));
		btnStart2.setBounds(450, 390, 151, 30);
		contentPane.add(btnStart2);
		btnStart2.setOpaque(true);	
		
		
		btnStart2.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			 AudioClip clip=Applet .newAudioClip(sound);
			 clip.play();
			 dispose();
				level2 ob = new level2();
				ob.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				ob.setSize(1100,550);
				ob.setVisible(true);
				ob.setLocationRelativeTo(null);
			}
		});
			
		//Information window ---------------------------------------------------------------------------
		JButton btnInfo= new JButton("Information");
		btnInfo.setBounds(470, 430, 120, 30);
		btnInfo.setForeground(new Color(47, 79, 79));
		btnInfo.setBackground(new Color(245, 222, 179));
		contentPane.add(btnInfo);
		btnInfo.setOpaque(true);
		btnInfo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				info ob = new info();
				ob.setSize(430,550);
				ob.setVisible(true);
				ob.setLocationRelativeTo(null);		
			}
		});
		
		//Names label---------------------------------------------------------------------------
		JLabel names = new JLabel("@Designed by: Alaa Talal, Amirah Bajaba, Huda Khalifi and Shoroq Naji");
		getContentPane().add(names);
		names.setBounds(320, 0,500, 1000);
		
		
		//Game main window ---------------------------------------------------------------------------
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(Start.class.getResource("oic2.png")));
		lblNewLabel.setBounds(-237, 0, 1286, 642);
		contentPane.add(lblNewLabel);
		
		
	
		
	}
	
	
	
	public static void main(String[] args)  {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Start frame = new Start();
					frame.setSize(1025,650);
					frame.setVisible(true);
					frame.setLocationRelativeTo(null);
					frame.setResizable(false);
			
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
	}
}